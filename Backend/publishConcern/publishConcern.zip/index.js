// Import the Google Cloud client library
const { PubSub } = require('@google-cloud/pubsub');

// Import AWS SDK and configure DynamoDB
const { DynamoDB } = require('@aws-sdk/client-dynamodb');
const dynamodb = new DynamoDB({ region: 'us-east-1' });

exports.handler = async function(event) {
  const projectId = './serviceAccountKey.json'; // Path to your service account key file
  const topicName = 'publishConcern'; // Name of the concern topic
  const tableName = 'Communications'; // DynamoDB table name

  // Instantiates a client
  const pubsub = new PubSub({ keyFilename: projectId });

  try {
    // Reference an existing topic
    const topic = pubsub.topic(topicName);

    // The message to publish, passed from the event
    const { message, author } = event; // Ensure the event contains message and author fields
    const dataBuffer = Buffer.from(message);

    // Publish the message
    const messageId = await topic.publishMessage({ data: dataBuffer });
    console.log(`Message ${messageId} published.`);

    // Log the communication to DynamoDB
    const params = {
      TableName: tableName,
      Item: {
        messageId: { S: messageId }, // DynamoDB requires the data type for the item attributes
        message: { S: message },
        author: { S: author },
        timestamp: { S: new Date().toISOString() } // Using ISO format for timestamp
      }
    };

    await dynamodb.putItem(params);
    console.log(`Logged communication to DynamoDB with messageId ${messageId}.`);

    return {
      statusCode: 200,
      body: JSON.stringify(`Message ${messageId} published and logged.`)
    };
  } catch (error) {
    console.error('Error:', error);
    return {
      statusCode: 500,
      body: JSON.stringify(`Error: ${error.message}`)
    };
  }
};
