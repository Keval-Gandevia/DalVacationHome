import json
import boto3
import urllib3
import string
import secrets

http = urllib3.PoolManager()
dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table('Rooms')

def lambda_handler(event, context):
    body = json.loads(event['body'])
    room_id = body['roomId']
    comment = body['comment']
    
    api_url = "https://us-central1-csci-5410-serverless-428201.cloudfunctions.net/feedback-analysis"
    payload = {"comment": comment}
    headers = {'Content-Type': 'application/json'}
    try:
        response_api = http.request(
            'POST',
            api_url,
            body=json.dumps(payload),
            headers=headers
        )
        if response_api.status == 200:
            analysis_result = json.loads(response_api.data.decode('utf-8'))
            polarity = analysis_result.get("sentiment", "neutral")
        else:
            print(f"Non-200 response: {response_api.status}")
            polarity = "neutral"  
    except Exception as e:
        print(f"Error calling feedback analysis API: {e}")
        polarity = "neutral" 
    
    try:
        response = table.get_item(Key={'room_id': room_id})
        room = response.get('Item')
        if room:
            comment_id = generate_random_id()
            print(comment_id)
            room['comments'][comment_id] = [comment, polarity]
            table.update_item(
                Key={'room_id': room_id},
                UpdateExpression='SET comments = :val1',
                ExpressionAttributeValues={
                    ':val1': room['comments']
                }
            )
            return buildResponse(200, room['comments'])
        else:
            return buildResponse(404, {'message': 'Room not found'})
    except Exception as e:
        print(e)
        return buildResponse(500, {'message': 'Error fetching room '})

def buildResponse(statusCode, body=None):
    response = {
        'statusCode': statusCode,
        'headers': {
            "Access-Control-Allow-Headers" : "Content-Type",
            "Access-Control-Allow-Origin": "*",
            "Content-Type": "application/json",
            "Access-Control-Allow-Methods": "OPTIONS,POST,GET,PATCH"
        }
    }
    if body is not None:
        response['body'] = json.dumps(body)
    return response
    
def generate_random_id(length=6):
    characters = string.ascii_letters + string.digits
    random_id = ''.join(secrets.choice(characters) for _ in range(length))
    return random_id