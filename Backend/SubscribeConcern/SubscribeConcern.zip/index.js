// Import the Google Cloud client library
const { PubSub } = require('@google-cloud/pubsub');
// Import AWS SDK v3 clients and commands
const { DynamoDBClient, ScanCommand } = require('@aws-sdk/client-dynamodb');

const dynamodb = new DynamoDBClient({ region: 'us-east-1' });

exports.handler = async function(event, context) {
  const projectId = './serviceAccountKey.json'; // Path to your service account key file
  const subscriptionName = event['user']; // Name of your response subscription
  const tableName = 'Communications'; // DynamoDB table name

  // Instantiates a client
  // const pubsub = new PubSub({ keyFilename: projectId });

  // Reference an existing subscription
  // const subscription = pubsub.subscription(subscriptionName);

  let newMessage;

  // Message handler
  // const messageHandler = message => {
  //   console.log(`Received message ${message.id}:`);
  //   console.log(`\tData: ${message.data}`);
  //   console.log(`\tAttributes: ${JSON.stringify(message.attributes)}`);
  //   newMessage = message.data.toString(); // Store the new message
  //   message.ack(); // Acknowledge message receipt
  // };

  // Error handler
  // const errorHandler = error => {
  //   console.error('Received error:', error);
  //   context.fail(error.message);
  // };

  try {
    // Listen for new messages until timeout is hit
    // subscription.on('message', messageHandler);
    // subscription.on('error', errorHandler);

    // // Run the listener for a specified amount of time (e.g., 10 seconds)
    // await new Promise(resolve => setTimeout(resolve, 10000));

    // // Remove listeners to clean up
    // subscription.removeListener('message', messageHandler);
    // subscription.removeListener('error', errorHandler);

    // Fetch existing items from DynamoDB
    const params = {
      TableName: tableName
    };

    try {
      const command = new ScanCommand(params);
      const { Items } = await dynamodb.send(command);

      // Extract all messages, authors, and timestamps from the fetched items
      const allMessages = Items.map(item => ({
        author: item.author ? item.author.S : 'No author found',
        message: item.message ? item.message.S : 'No message found',
        timestamp: item.timestamp ? item.timestamp.S : 'No timestamp found'
      }));

      // Sort messages by timestamp
      allMessages.sort((a, b) => new Date(a.timestamp) - new Date(b.timestamp));

      console.log('All fetched messages:', allMessages);

      context.succeed({
        statusCode: 200,
        body: JSON.stringify({
          messages: allMessages
        })
      });

    } catch (dynamoError) {
      console.error('Error fetching items from DynamoDB:', dynamoError);
      context.fail({
        statusCode: 500,
        body: JSON.stringify({
          error: dynamoError.message
        })
      });
    }

  } catch (error) {
    console.error('Error:', error);
    context.fail({
      statusCode: 500,
      body: JSON.stringify({
        error: error.message
      })
    });
  }
};
