import json
import boto3
import requests

def lambda_handler(event, context):
    # Role to assume in the Lex account
    role_to_assume_arn = "arn:aws:iam::381491943291:role/LexBotAccessRole"

    # Assume the role
    sts_client = boto3.client('sts')
    assumed_role_object = sts_client.assume_role(
        RoleArn=role_to_assume_arn,
        RoleSessionName="LexBotAccessSession"
    )

    # Get temporary credentials
    credentials = assumed_role_object['Credentials']
    access_key = credentials['AccessKeyId']
    secret_key = credentials['SecretAccessKey']
    session_token = credentials['SessionToken']

    # Create a Lex client with the temporary credentials
    lex_client = boto3.client(
        'lex-runtime',
        aws_access_key_id=access_key,
        aws_secret_access_key=secret_key,
        aws_session_token=session_token,
        region_name='us-east-1'
    )

    # Define the Lex bot details
    bot_name = "NavigationHelper"
    bot_alias = "lexbot"
    user_id = "rajChauhan101"  # Unique user ID
    text_to_post = event['text']

    # Call the Lex bot
    response = lex_client.post_text(
        botName=bot_name,
        botAlias=bot_alias,
        userId=user_id,
        inputText=text_to_post
    )

    def format_room_info(room_data):
        room_name = room_data.get('room_name', 'No room name found')
        room_type = room_data.get('room_type', 'No room type found')
        reservation_dates = room_data.get('reservation_dates', {})

        # Create the stay duration text
        stay_duration = ""
        if reservation_dates:
            dates = list(reservation_dates.keys())
            if len(dates) > 1:
                stay_duration = f"Stay duration: From {dates[0]} to {dates[-1]}"
            else:
                stay_duration = f"Stay date: {dates[0]}"

        # Create the details text
        details = (
            f"Room Name: {room_name}\n"
            f"Room Type: {room_type}\n"
            f"{stay_duration}\n"
            f"Location: {room_data.get('location', 'No location found')}\n"
            f"Capacity: {room_data.get('capacity', 'No capacity found')}\n"
            f"Price per night: ${room_data.get('price', 'No price found')}\n"
            f"Amenities: {', '.join(room_data.get('amenities', []))}\n"
            f"Description: {room_data.get('description', 'No description found')}"
        )

        return details

    # Extract the triggered intent and fulfillment status
    intent_name = response.get('intentName')
    fulfillment_status = response.get('dialogState')
    bot_response = response.get('message')

    # Check if the intent is "publishConcern" and is fulfilled
    if intent_name == "publishConcern" and fulfillment_status == 'Fulfilled':
        # Create a DynamoDB client
        dynamodb = boto3.client('dynamodb', region_name='us-east-1')
        table_name = 'Communications'

        # Scan the table to get all items
        scan_params = {
            'TableName': table_name
        }

        try:
            while True:
                scan_response = dynamodb.scan(**scan_params)
                items = scan_response.get('Items', [])

                # Delete each item
                for item in items:
                    # Ensure to specify the primary key correctly
                    key = {
                        'messageId': item['messageId']  # Replace 'messageId' with your actual partition key name and ensure it's correctly accessed
                    }
                    delete_params = {
                        'TableName': table_name,
                        'Key': key
                    }
                    dynamodb.delete_item(**delete_params)
                    print(f"Deleted item: {key}")

                # Check if there are more items to scan
                if 'LastEvaluatedKey' not in scan_response:
                    break
                scan_params['ExclusiveStartKey'] = scan_response['LastEvaluatedKey']

            print(f"All items from table {table_name} deleted.")
        except Exception as e:
            print(f"Error deleting items from DynamoDB: {e}")

        # Invoke the target Lambda function
        lambda_client = boto3.client('lambda')

        payload = {
            'message': text_to_post,
            'author': 'user'
        }

        try:
            invoke_response = lambda_client.invoke(
                FunctionName='publishConcern',  # The name of the target Lambda function
                InvocationType='Event',  # Use 'Event' for asynchronous invocation
                Payload=json.dumps(payload)
            )
            print(f"Invoked Lambda function response: {invoke_response}")
        except Exception as e:
            print(f"Error invoking Lambda function: {e}")

    # Check if the intent is "BookHotel" and has a bookingID slot value, then call the reservation details API
    if intent_name == "BookHotel" and fulfillment_status == 'Fulfilled':
        booking_id = response.get('slots', {}).get('bookingID')
        if booking_id:
            api_url_reservation = "https://hl8ej942eh.execute-api.us-east-1.amazonaws.com/prod/reservation-details"
            api_payload_reservation = {
                'reservationId': booking_id
            }

            try:
                # Call the reservation details API
                api_response_reservation = requests.post(api_url_reservation, json=api_payload_reservation)
                api_response_data_reservation = api_response_reservation.json()
                print(f"API response (reservation details): {api_response_data_reservation}")
                
                # Check if the API response is empty or null
                room_id = api_response_data_reservation.get('room_id')
                if not room_id:
                    return {
                        'statusCode': 200,
                        'body': json.dumps({
                            'botResponse': "No details found!"
                        })
                    }

                # Call the room details API with the room_id
                api_url_room = "https://hl8ej942eh.execute-api.us-east-1.amazonaws.com/prod/room-details"
                api_payload_room = {
                    'roomId': room_id
                }

                api_response_room = requests.post(api_url_room, json=api_payload_room)
                api_response_data_room = api_response_room.json()

                formatted_room_details = format_room_info(api_response_data_room)

                # Return the room details in text format
                return {
                    'statusCode': 200,
                    'body': json.dumps({
                        'botResponse': formatted_room_details
                    })
                }
            except Exception as e:
                print(f"Error calling reservation details or room details API: {e}")
                return {
                    'statusCode': 500,
                    'body': json.dumps({
                        'error': str(e)
                    })
                }

    return {
        'statusCode': 200,
        'body': json.dumps({
            'botResponse': bot_response
        })
    }
