import { DynamoDBClient, GetItemCommand } from "@aws-sdk/client-dynamodb";

const dynamodb = new DynamoDBClient();

const usersTable = 'Users';
const securityQuestionAnswerTable = 'SecurityQuestionAnswer';

export const handler = async (event) => {
  const email = event.queryStringParameters.email;

  const getUserParams = {
    TableName: usersTable,
    Key: {
      email: { S: email },
    },
  };

  const getSecurityParams = {
    TableName: securityQuestionAnswerTable,
    Key: {
      email: { S: email },
    },
  };

  try {
    const [userResult, securityResult] = await Promise.all([
      dynamodb.send(new GetItemCommand(getUserParams)),
      dynamodb.send(new GetItemCommand(getSecurityParams)),
    ]);

    const caesarCipherKey = userResult.Item?.caesarCipherKey?.S;
    const securityQuestionAnswer = securityResult.Item?.answer?.S;

    if (!caesarCipherKey || !securityQuestionAnswer) {
      throw new Error('User or security question answer not found');
    }

    const response = {
      caesarCipherKey,
      securityQuestionAnswer,
    };

    return {
      statusCode: 200,
      body: JSON.stringify(response),
    };
  } catch (err) {
    console.error(`Error fetching user details: ${err.message}`);
    return {
      statusCode: 500,
      body: JSON.stringify({ message: 'Error fetching user details' }),
    };
  }
};
