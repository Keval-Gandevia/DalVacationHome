import { DynamoDBClient, PutItemCommand, UpdateItemCommand } from "@aws-sdk/client-dynamodb";
import { SNSClient, PublishCommand, CreateTopicCommand, SubscribeCommand } from "@aws-sdk/client-sns";

const dynamodb = new DynamoDBClient();
const sns = new SNSClient();

const usersTable = 'Users';
const securityQuestionAnswerTable = 'SecurityQuestionAnswer';

export const handler = async (event) => {
  const { userAttributes } = event.request;

  const userItem = {
    firstName: { S: userAttributes['custom:firstName'] },
    lastName: { S: userAttributes['custom:lastName'] },
    email: { S: userAttributes.email },
    role: { S: userAttributes['custom:role'] },
    caesarCipherKey: { S: userAttributes['custom:caesarCipherKey'] },
  };

  const securityQuestionAnswerItem = {
    email: { S: userAttributes.email },
    answer: { S: userAttributes['custom:securityQueAns'] },
  };

  const putUserParams = {
    TableName: usersTable,
    Item: userItem,
  };

  const putSecurityParams = {
    TableName: securityQuestionAnswerTable,
    Item: securityQuestionAnswerItem,
  };

  try {
    await Promise.all([
      dynamodb.send(new PutItemCommand(putUserParams)),
      dynamodb.send(new PutItemCommand(putSecurityParams)),
    ]);

    // Create a unique topic name using the first name
    const topicName = `ConfirmationTopic-${userAttributes['custom:firstName']}`;
    const createTopicResponse = await sns.send(new CreateTopicCommand({ Name: topicName }));
    const topicArn = createTopicResponse.TopicArn;

    // Subscribe the email to the topic
    await sns.send(new SubscribeCommand({
      TopicArn: topicArn,
      Protocol: 'email',
      Endpoint: userAttributes.email,
    }));

    // Send confirmation message
    await sns.send(new PublishCommand({
      TopicArn: topicArn,
      Message: `Your registration was successful, ${userAttributes['custom:firstName']}!`,
      Subject: 'DALVACATIONHOME - Registration Confirmation',
    }));

    // Update DynamoDB with the topicArn
    const updateUserParams = {
      TableName: usersTable,
      Key: {
        email: { S: userAttributes.email },
      },
      UpdateExpression: 'SET topicArn = :topicArn',
      ExpressionAttributeValues: {
        ':topicArn': { S: topicArn },
      },
    };
    
    await dynamodb.send(new UpdateItemCommand(updateUserParams));
    
    console.log("User details stored and email sent successfully!");
    return event;
  } catch (err) {
    console.error(`Error storing user details or sending email: ${err.message}`);
    throw new Error('Error storing user details or sending email');
  }
};
