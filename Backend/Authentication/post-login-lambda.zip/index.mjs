import { DynamoDBClient, GetItemCommand } from "@aws-sdk/client-dynamodb";
import { SNSClient, PublishCommand } from "@aws-sdk/client-sns";
import { BigQuery } from '@google-cloud/bigquery';

const dynamodb = new DynamoDBClient();
const sns = new SNSClient();
const bigquery = new BigQuery();

const usersTable = 'Users';

export const handler = async (event) => {
  
  const email = event.queryStringParameters.email;

  const getUserParams = {
    TableName: usersTable,
    Key: {
      email: { S: email },
    },
  };
  
  try {
    const userResult = await dynamodb.send(new GetItemCommand(getUserParams));
    if (!userResult.Item) {
      throw new Error('User not found');
    }

    const topicArn = userResult.Item.topicArn.S;
    const firstName = userResult.Item.firstName.S;
    const lastName = userResult.Item.lastName.S;
    const role = userResult.Item.role.S;
    
    await sns.send(new PublishCommand({
      TopicArn: topicArn,
      Message: `You have successfully signed in, ${firstName}!`,
      Subject: 'DALVACATIONHOME - Sign-In Confirmation',
    }));

    console.log("Sign-in confirmation sent successfully!");
    
    // Insert login record into BigQuery
    const datasetId = 'serverless_project_users_dataset';
    const tableId = 'UsersLogin';
    const timestamp = new Date().toISOString();
    
    const row = {
      email,
      role,
      firstName,
      lastName,
      timestamp,
    };

    await bigquery
      .dataset(datasetId)
      .table(tableId)
      .insert(row);
    
    console.log("Sign-in confirmation sent and login record inserted successfully!");
    return {
      statusCode: 200,
      body: JSON.stringify({ message: 'Sign-in confirmation sent and login record inserted successfully!' }),
    };
  } catch (err) {
    console.error(`Error sending sign-in confirmation: ${err.message}`);
    return {
      statusCode: 500,
      body: JSON.stringify({ message: 'Error sending sign-in confirmation' }),
    };
  }
};
