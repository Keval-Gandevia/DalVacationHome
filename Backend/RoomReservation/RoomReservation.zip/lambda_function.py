import json
import boto3
import random

def lambda_handler(event, context):
    dynamodb = boto3.resource('dynamodb')
    sns = boto3.client('sns')
    data = json.loads(event['Records'][0]['body'])
    room_id = data['room_id']
    date = data['date']
    people = data['people']
    guest_id = data['guest_id']
    
    user_table =  dynamodb.Table('Users')
    user_response = user_table.get_item(Key={'email': guest_id})
    topicArn = user_response["Item"]["topicArn"]
    
    reservation_code = str(random.randint(100000, 999999))

    table_room = dynamodb.Table('Rooms')
    # Attempt to retrieve existing reservation dates for the room
    try:
        room_response = table_room.get_item(Key={'room_id': room_id})
        if 'Item' in room_response and 'reservation_dates' in room_response['Item'] and date in room_response['Item']['reservation_dates']:
            # Date is already booked, send failure email
            email_subject = "Reservation Failed"
            email_message = f"Unfortunately, room {room_response['Item']['room_name']} is already booked for {date}. Please try another date."
            sns_response = sns.publish(
                TopicArn=topicArn, 
                Message=email_message,
                Subject=email_subject
            )
            return {
                'statusCode': 409,  # Conflict status code
                'body': json.dumps({'message': 'Reservation failed due to date conflict', 'error': 'Date is already booked'})
            }
        else:
            table_reservation = dynamodb.Table('Reservations')
            reservation_data = {
                'reservation_id': reservation_code,
                'room_id': room_id,
                'date': date,
                'people': people,
                'guest_id': guest_id
            }
            response = table_room.update_item(
                    Key={'room_id': room_id},
                    UpdateExpression="SET reservation_dates.#date = :guest_id",
                    ExpressionAttributeNames={'#date': date},
                    ExpressionAttributeValues={':guest_id': guest_id},
                    ReturnValues="UPDATED_NEW"
                )
            table_reservation.put_item(Item=reservation_data)
            print('Reservation successful:', reservation_data)
            email_subject = "Reservation Confirmation"
            email_message = f"Your reservation for room  {room_response['Item']['room_name']} on {date} is confirmed. Your reservation code is {reservation_code}."
            sns_response = sns.publish(
                TopicArn=topicArn, 
                Message=email_message,
                Subject=email_subject
            )
            return {
                'statusCode': 200,
                'body': json.dumps({'message': 'Reservation successful', 'reservationCode': reservation_code, "room_update": response})
            }
    except Exception as e:
        print('Reservation failed:', e)
        return {
            'statusCode': 500,
            'body': json.dumps({'message': 'Reservation failed', 'error': str(e)})
        }