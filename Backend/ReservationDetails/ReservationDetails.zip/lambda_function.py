import json
from decimal import Decimal
import boto3

dynamodb = boto3.resource('dynamodb')

table = dynamodb.Table('Reservations')

class DecimalEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, Decimal):
            return float(obj)  # or str(obj) if you want to preserve exactness
        return super(DecimalEncoder, self).default(obj)

def lambda_handler(event, context):
    body = json.loads(event['body'])
    reservation_id = body['reservationId']
    
    try:
        response = table.get_item(
            Key={
                'reservation_id': reservation_id
            }
        )
        if 'Item' in response:
            print(response['Item'])
            return buildResponse(200, response['Item'])
        else:
            return buildResponse(404, {'message': 'Reservation not found'})
            
    except Exception as e:
        print(e)
        return buildResponse(500, {'message': 'Error fetching Reservation details'})
        
def buildResponse(statusCode, body=None):
    response = {
        'statusCode': statusCode,
        'headers': {
            "Access-Control-Allow-Headers" : "Content-Type",
            "Access-Control-Allow-Origin": "*",
            "Content-Type": "application/json",
            "Access-Control-Allow-Methods": "OPTIONS,POST,GET,PATCH"
        }
    }
    if body is not None:
        response['body'] = json.dumps(body, cls=DecimalEncoder)
    return response