import AWS from 'aws-sdk';
import { BigQuery } from '@google-cloud/bigquery';
import fs from 'fs';
import path from 'path';

// Set the path to the service account key file
process.env.GOOGLE_APPLICATION_CREDENTIALS = '/var/task/service-account-key.json';

// Initialize DynamoDB client
const dynamodb = new AWS.DynamoDB.DocumentClient();
const bigquery = new BigQuery();

export const handler = async (event) => {
    console.log(event);
    console.log('Received event:', JSON.stringify(event, null, 2));
    
    try {
        if (Array.isArray(event.Records)) {
            for (const record of event.Records) {
                if (record.eventName === 'INSERT') {
                    const newUser = AWS.DynamoDB.Converter.unmarshall(record.dynamodb.NewImage);

                    const userData = {
                        firstName: newUser.firstName,
                        lastName: newUser.lastName,
                        email: newUser.email,
                    };

                    const datasetId = 'serverless_project_users_dataset';
                    const tableId = 'Users';

                    await bigquery
                        .dataset(datasetId)
                        .table(tableId)
                        .insert(userData);

                    console.log(`Inserted user data: ${JSON.stringify(userData)}`);
                }
            }
        } else {
            throw new Error('Event does not contain Records array');
        }
    } catch (err) {
        console.error('Error inserting data into BigQuery', err);
        throw new Error('Error inserting data into BigQuery');
    }

    return {
        statusCode: 200,
        body: 'User data inserted into BigQuery'
    };
};
