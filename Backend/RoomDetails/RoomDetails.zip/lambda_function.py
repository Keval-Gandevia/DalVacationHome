import json
import boto3

dynamodb = boto3.resource('dynamodb')

table = dynamodb.Table('Rooms')

def lambda_handler(event, context):

    body = json.loads(event['body'])
    room_id = body['roomId']
    
    try:
        response = table.get_item(
            Key={
                'room_id': room_id
            }
        )
        if 'Item' in response:
            print(response['Item'])
            return buildResponse(200, response['Item'])
        else:
            return buildResponse(404, {'message': 'Room not found'})
            
    except Exception as e:
        print(e)
        return buildResponse(500, {'message': 'Error fetching room details'})
        
def buildResponse(statusCode, body=None):
    response = {
        'statusCode': statusCode,
        'headers': {
            "Access-Control-Allow-Headers" : "Content-Type",
            "Access-Control-Allow-Origin": "*",
            "Content-Type": "application/json",
            "Access-Control-Allow-Methods": "OPTIONS,POST,GET,PATCH"
        }
    }
    if body is not None:
        response['body'] = json.dumps(body)
    return response